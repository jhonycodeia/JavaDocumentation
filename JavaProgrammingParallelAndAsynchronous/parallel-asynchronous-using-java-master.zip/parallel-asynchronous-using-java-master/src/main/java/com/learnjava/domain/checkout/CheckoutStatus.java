package com.learnjava.domain.checkout;

public enum CheckoutStatus {
    SUCCESS,
    FAILURE
}
